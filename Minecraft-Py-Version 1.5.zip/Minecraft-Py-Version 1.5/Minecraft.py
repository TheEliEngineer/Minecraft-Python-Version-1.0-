from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()

# Load your texture
grass_texture = load_texture('grass.png')

class Block(Button):
    def __init__(self, position=(0,0,0)):
        super().__init__(
            parent=scene,
            model='cube',
            texture=grass_texture,
            color=color.white,
            position=position,
            scale=1,
            origin_y=0.5,
            highlight_color=color.lime
        )

# Make a flat 10x10 block world
for z in range(10):
    for x in range(10):
        Block(position=(x, 0, z))

player = FirstPersonController()
Sky()
app.run()

